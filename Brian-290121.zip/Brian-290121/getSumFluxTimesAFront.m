%gets the sum of the products of the photon flux and the absorption 
%coefficient for front illumination
function [sumFluxTimesA, J_limit] = getSumFluxTimesAFront(activelayerthickness)
[PECabsorption, ~, ~, PECabsCoeff, PECactiveLayer, lambdaPEC, maxJsc] = TransferMatrixPEC(activelayerthickness);
%note: absCoeff is in cm-1
PECabsorption; % in fraction (0-1)
lambdaPEC;
PECabsCoeff;
spectrumData = load('spectrum.mat');  %% Brian - new NREL flux spectrum
flux = (spectrumData.fluxLambda).';  % Brian - New flux.m-2 data
fluxRange = (spectrumData.lambda).';  %%Brian - each nm from 300 - 900 nm
fluxInterp = interp1(fluxRange, flux, lambdaPEC, 'linear', 'extrap');
fluxInterp;
photonFlux = fluxInterp; %in flux.m-2.s-1.nm-1 %Brian new version
photonFlux;

J_limit = maxJsc*10 %A/m2 originally mA/cm2

%% Brian comment out ... photonFluxAbsorbed = photonFlux.*PECabsorption(PECactiveLayer, :); %% Brian flux.m-2.s-1.nm-1
photonFluxAbsorbed = photonFlux.*PECabsorption(PECactiveLayer, :);

fluxTimesA = photonFlux.*(PECabsCoeff(PECactiveLayer,:).*100); %flux.m-2.s-1.nm-1.m-1

sumFluxTimesA = sum(fluxTimesA);
%sumFluxTimesA = sum(fluxTimesA, 2); %Brian changed above 280121
end





